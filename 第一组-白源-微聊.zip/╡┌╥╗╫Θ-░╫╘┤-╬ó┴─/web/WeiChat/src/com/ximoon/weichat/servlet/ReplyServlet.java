package com.ximoon.weichat.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ximoon.weichat.dao.UserDao;
import com.ximoon.weichat.entity.BarUserInfo;

public class ReplyServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");//如果写错,提示你下载
		PrintWriter out = response.getWriter();
		//获取回复内容
		String reply_layer = request.getParameter("reply_layer");
		String theme = request.getParameter("theme");
		String title_reply = request.getParameter("title_reply");
		String reply_time = request.getParameter("reply_time");
		String userName = request.getParameter("userName");
//		int answer_layer = 2;
		int answer_layer = Integer.parseInt(request.getParameter("answer_layer"));
		int user_id = Integer.parseInt(request.getParameter("user_id"));
//		System.out.println(reply_layer);
		BarUserInfo BarUserInfo=new BarUserInfo(0,theme,title_reply,answer_layer,reply_layer,reply_time,user_id,userName,null);
		//判断
		UserDao dao=new UserDao();
		boolean flag=dao.insertReply(BarUserInfo);
		boolean flag_layer=dao.insertLayer(title_reply,answer_layer);
		if(flag_layer&&flag){
			//插入成功
			out.println("ok");
		}else{
			//插入失败
			out.println("no");
			
		}
		out.flush();
		out.close();
	}

}
