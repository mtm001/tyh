package com.ximoon.weichat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import com.ximoon.weichat.dao.LoginDao;
import com.ximoon.weichat.entity.RecordMsgInfo;
import com.ximoon.weichat.entity.UserInfo;

public class ClientThread extends Thread {

	public UserInfo info = null;
	public Socket socket = null;
	public String ip = null;
	public int port = 0;
	private InputStream is = null;
	private BufferedReader reader = null;
	private OutputStream os = null;
	private PrintWriter writer = null;
	public List<ClientThread> list = new ArrayList<ClientThread>();

	public ClientThread() {

	}

	public ClientThread(Socket socket) {
		this.socket = socket;
		this.ip = socket.getInetAddress().getHostAddress();
		this.port = socket.getPort();
		try {
			this.socket.setKeepAlive(true);
			this.socket.setSoTimeout(600000);
			this.is = socket.getInputStream();
			this.reader = new BufferedReader(new InputStreamReader(is));
			this.os = socket.getOutputStream();
			this.writer = new PrintWriter(os);
		} catch (Exception e) {
			e.printStackTrace();
		}
		start();
	}

	public void sendMessage(String msg) {
		writer.println(msg);
		writer.flush();
		System.out.println(this.ip+this.port);
	}

	public String getMessage() {
		String msg = null;
		try {
			if (socket.isConnected() && !socket.isClosed()) {
				msg = reader.readLine();
			}
		} catch (IOException e) {
//			System.out.println(socket.isConnected()+"==="+socket.isClosed());
		}
		return msg;
	}
	
	public void close() throws Exception{
		this.writer.close();
		this.os.close();
		this.reader.close();
		this.is.close();
		this.socket.close();
	}

	public void run() {
		while (socket.isConnected() && !socket.isClosed()) {
			String msg = getMessage();
			if (null != msg) {
				String operation = msg.split("@")[0];
				try {
					if (operation.equals("exit")) {
						System.out.println("下线");
						LoginDao.changeState(info._id, false);
						if (this.info == null) {
							continue;
						}
						SNSServer.clients.remove(this);
						for (ClientThread client : this.list) {
							//通知好友该用户已下线
							String msg_exit = "exit@" + this.info._id ;
							client.sendMessage(msg_exit);
						}
//						this.stop();
//						this.close();
						break;
					} else if (operation.equals("login")) {
						//判断用户是否登陆成功
						info = new UserInfo();
						info.username = msg.split("@")[1];
						info.password = msg.split("@")[2];
						info = LoginDao.login(info);
						if (info == null) {
							//登陆未成功
							msg = "error@";
							this.sendMessage(msg);
							SNSServer.clients.remove(this);
							System.out.println("登陆失败");
						} else {
							String msg_succeed = "succeed@" + info._id + "@" + info.username + "@" + info.nickname + "@" + info.motto + "@" + info.headicon + "@" + info.birth + "@" + info.phone + "@" + info.sex;
							this.sendMessage(msg_succeed);
							
							LoginDao.changeState(info._id, true);
							System.out.println("登陆成功");
							System.out.println(info.toString());
							//登陆成功后，已上线的用户从好友关系表中查找到新上线的用户是否为好友，如果是好友则刷新好友列表
							//已登录的用户则刷新好友列表
							for (ClientThread client : SNSServer.clients) {
								System.out.println("已登录用户刷新列表中");
								UserInfo friend = LoginDao.isFriend(
										client.info._id, this.info._id);
								System.out.println(null== friend? true :false);
								if (null != friend) {
									info.exname = friend.exname;
									String msg_new = onlineMsg(this);
									client.sendMessage(msg_new);
									client.list.add(this);
									list.add(client);
									System.out.println(list.size());
								}
							}
							//新登陆用户刷新好友列表
							
							for (ClientThread client : list) {
								System.out.println("新登录用户刷新列表中");
								UserInfo friend = LoginDao.isFriend(
										this.info._id, client.info._id);
								client.info.exname = friend.exname;
								String msg_old = onlineMsg(client);
								this.sendMessage(msg_old);
							}
							SNSServer.clients.add(this);
							if (info.isonline) {
								int i = 0;
								for (ClientThread thread : SNSServer.clients) {
									i++;
									if (thread.info._id == info._id && i != SNSServer.clients.size()) {
										SNSServer.clients.set(i - 1, this);
										SNSServer.clients.remove(SNSServer.clients.size() - 1);
										break;
									}
								}
							}
						}
					}else if(operation.equals("register")){
						System.out.println("正在注册");
						UserInfo info = new UserInfo();
						info.username = msg.split("@")[1];
						info.password = msg.split("@")[2];
						System.out.println(info.toString());
						boolean flag = LoginDao.register(info);
						if (flag) {
							this.sendMessage("ok@");
							System.out.println("成功");
						}else{
							this.sendMessage("faile@");
							System.out.println("失败");
						}
					}else if (operation.equals("chat")) {
						RecordMsgInfo record = new RecordMsgInfo();
						int sender__id = Integer.parseInt(msg.split("@")[2]);
						int receiver__id = Integer.parseInt(msg.split("@")[1]);
						record.flag = sender__id + "@" + receiver__id;
						String choose = msg.split("@")[3];
						if ("text".equals(choose)) {
							record.msg = "";
							for (int i = 4; i < msg.split("@").length; i++) {
								record.msg = record.msg + msg.split("@")[i] + "@";
							}
							record.msg = record.msg.substring(0, record.msg.length() - 2);
						}else if ("img".equals(choose)) {
							record.img = "";
							for (int i = 4; i < msg.split("@").length; i++) {
								record.img = record.img + msg.split("@")[i] + "@";
							}
							record.img = record.img.substring(0, record.img.length() - 2);
						}else if ("voice".equals(choose)) {
							record.voice = "";
							for (int i = 4; i < msg.split("@").length ; i++) {
								record.voice = record.voice + msg.split("@")[i] + "@";
							}
							record.voice = record.voice.substring(0, record.voice.length() - 2);
						}else if ("emoji".equals(choose)) {
							record.emoji = Integer.parseInt(msg.split("@")[4]);
						}
						for (ClientThread thread : list) {
							if (thread.info._id == receiver__id) {
								System.out.println(msg);
								thread.sendMessage(msg);
							}
						}
						if ("file".equals(choose)) {
							continue;
						}
						LoginDao.recordChating(record);
					}
				} catch (Exception e) {
					System.out.println("客户端退出");
				}
			}
		}
	}

	private String onlineMsg(ClientThread c) {
		String msg_new = "online@" + c.ip + "@" + // ip
				c.port + "@" + // 端口号
				c.info._id + "@" + // 用户id
				c.info.username + "@" + // 用户登录名
				c.info.nickname + "@" + // 用户昵称
				c.info.motto + "@" + // 用户签名
				c.info.headicon + "@" + 
				c.info.exname; // 用户头像
		return msg_new;
	}
}