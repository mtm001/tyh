package com.ximoon.weichat.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class BaseDao {
	private static final String DRIVER = "com.mysql.jdbc.Driver";
	private static final String URL = "jdbc:mysql://localhost:3306/weichat?useUnicode=true&characterEncoding=UTF-8";
	private static final String USERNAME = "root";
	private static final String PASSWORD = "";
	protected static Connection conn;
	protected static PreparedStatement pstm;
	protected static ResultSet rs;


	public static Connection getConnection(){
		try {
			Class.forName(DRIVER);
			conn=DriverManager.getConnection(URL,USERNAME,PASSWORD);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	static{
		getConnection();
	}
	
	public ResultSet query(String sql,List<String> temp){
		try {
			if (conn.isClosed()) {
				conn = getConnection();
			}
			pstm=conn.prepareStatement(sql);
			if(null!=temp && temp.size()>0){
				for(int i=0;i<temp.size();i++){
					pstm.setObject(i+1,temp.get(i));
				}
			}
			rs=pstm.executeQuery();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rs;
	}
	public boolean update(String sql,List<String> temp){
		try {
			if (conn.isClosed()) {
				conn = getConnection();
			}
			pstm=conn.prepareStatement(sql);
			if(null!=temp&&temp.size()>0){
				for(int i=0;i<temp.size();i++){
				pstm.setObject(i+1, temp.get(i));
				}
			}
			return pstm.executeUpdate()>0? true :false;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	public boolean add(String sql,List<String> temp){
		try {
			if (conn.isClosed()) {
				conn = getConnection();
			}
			pstm = conn.prepareStatement(sql);
			if(null != temp && temp.size() > 0){
				for(int i=0;i<temp.size();i++){
					System.out.println(temp.get(i)+"&&&&&");
					pstm.setString(i+1, temp.get(i));
				}
			}
			return pstm.executeUpdate()>0?true:false;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
		
	}
	public boolean remove(String sql,List<String> temp){
		try {
			if (conn.isClosed()) {
				conn = getConnection();
			}
			pstm = conn.prepareStatement(sql);
			if(null!=temp&&temp.size()>0){
				for(int i=0;i<temp.size();i++){
					pstm.setObject(i+1, temp.get(i));
				}
			}
			return pstm.executeUpdate()>0?true:false;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	public void closeAll(){
			try {
				if(null!=rs){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
					try {
						if(null!=pstm){
							pstm.close();
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}finally{
						try {
								if(conn!=null){
								conn.close();
								}
						} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
						}
						
					}
			}
	}
	
	public  int updateData(String sql,Object ...objects ){
		try {
			if (conn.isClosed()) {
				conn = getConnection();
			}			
			pstm = conn.prepareStatement(sql);
			if(objects!=null){
				for(int i=0;i<objects.length;i++){
					pstm.setObject(i+1, objects[i]);
				}
			}
			int s = pstm.executeUpdate();
			return s;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}
	
	
	public static void main(String[] args) {
		BaseDao.getConnection();
	}
}
