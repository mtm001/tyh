package com.ximoon.weichat.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ximoon.weichat.dao.LoginDao;
import com.ximoon.weichat.entity.UserInfo;

public class SetMessageServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		int _id = Integer.parseInt(request.getParameter("_id"));
		String nickname = request.getParameter("nickname");
		String phone = request.getParameter("phone");
		String motto = request.getParameter("motto");
		String sex = request.getParameter("sex");
		UserInfo info = new UserInfo();
		info._id = _id;
		info.nickname = nickname == null ? "" : nickname;
		info.phone = nickname == null ? "" : phone;
		info.motto = nickname == null ? "" : motto;
		info.sex = "男".equals(sex) ? "男" : "女";
		System.out.println(info);
		try {
			boolean flag = LoginDao.update(info);
			System.out.println(flag);
			out.write(flag ? "ok" : "no");
		} catch (Exception e) {
			e.printStackTrace();
		}
		out.flush();
		out.close();
	}

}