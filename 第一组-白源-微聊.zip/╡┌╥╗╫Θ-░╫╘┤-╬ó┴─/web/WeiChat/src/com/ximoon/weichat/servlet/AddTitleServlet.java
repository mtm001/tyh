package com.ximoon.weichat.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ximoon.weichat.dao.UserDao;
import com.ximoon.weichat.entity.BarUserInfo;

public class AddTitleServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");//如果写错,提示你下载
		PrintWriter out = response.getWriter();
		//获取回复内容
		String theme = request.getParameter("theme");
		String title = request.getParameter("title");
		int layer = Integer.parseInt(request.getParameter("layer"));
		String content = request.getParameter("content");
		String time = request.getParameter("time");
		int user_id = Integer.parseInt(request.getParameter("user_id"));
		String userName = request.getParameter("userName");
		String pic = request.getParameter("pic");
//		int answer_layer = 2;
//		System.out.println(reply_layer);
		BarUserInfo BarUserInfo=new BarUserInfo(0,theme,title,layer,content,time,user_id,userName,pic);
		//判断
		UserDao dao=new UserDao();
		boolean flag=dao.insertTitle(BarUserInfo);
		if(flag){
			//插入成功
			out.println("ok");
		}else{
			//插入失败
			out.println("no");
			
		}
		out.flush();
		out.close();
	}

}
