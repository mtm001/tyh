package com.ximoon.weichat.entity;




public class UserInfo {
	
	public int _id;
	public String username;
	public String password;
	public String ip;
	public int port;
	public String nickname;
	public boolean isNew;
	public String motto;
	public String headicon;
	public String phone;
	public String sex;
	public String birth;
	public boolean isonline;
	public String exname;
//	public List<UserInfo> friends;
	
	public UserInfo() {
		super();
	}

	public UserInfo(String ip, int port, boolean isNew) {
		super();
		this.ip = ip;
		this.port = port;
		this.isNew = isNew;
	}

	@Override
	public String toString() {
		return "UserInfo [_id=" + _id + ", birth=" + birth + ", exname="
				+ exname + ", headicon=" + headicon + ", ip=" + ip + ", isNew="
				+ isNew + ", isonline=" + isonline + ", motto=" + motto
				+ ", nickname=" + nickname + ", password=" + password
				+ ", phone=" + phone + ", port=" + port + ", sex=" + sex
				+ ", username=" + username + "]";
	}
	
}
