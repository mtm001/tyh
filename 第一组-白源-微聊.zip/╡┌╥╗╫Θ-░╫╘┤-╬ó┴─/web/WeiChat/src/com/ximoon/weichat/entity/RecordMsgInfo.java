package com.ximoon.weichat.entity;

public class RecordMsgInfo {

	public int _id;
	public String flag;
	public String msg;
	public String img;
	public String voice;
	public int emoji;
	public String time;
	
	public RecordMsgInfo() {
		super();
	}

	@Override
	public String toString() {
		return "RecordMsgInfo [_id=" + _id + ", emoji=" + emoji + ", flag="
				+ flag + ", img=" + img + ", msg=" + msg + ", time=" + time
				+ ", voice=" + voice + "]";
	}

}
