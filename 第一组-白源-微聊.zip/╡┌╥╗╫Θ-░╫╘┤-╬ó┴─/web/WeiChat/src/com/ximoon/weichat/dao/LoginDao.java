package com.ximoon.weichat.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.ximoon.weichat.entity.RecordMsgInfo;
import com.ximoon.weichat.entity.UserInfo;

public class LoginDao {
	
	public static UserInfo login(UserInfo info){
		BaseDao dao = new BaseDao();
		String sql = "select * from weiuser where username = ? and password = ?";
		List<String> temp = new ArrayList<String>();
		temp.add(info.username);
		temp.add(info.password);
		ResultSet set = dao.query(sql, temp);
		try {
			if (set.next()) {
				info._id = set.getInt("_id");
				info.nickname = set.getString("nickname");
				info.headicon = set.getString("headicon");
				info.motto = set.getString("motto");
				info.phone = set.getString("phone");
				info.sex = set.getString("sex");
				info.birth = set.getString("birth");
				info.isonline = set.getInt("isonline") == 0 ? false : true;
				return info;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static UserInfo search(UserInfo info){
		BaseDao dao = new BaseDao();
		String sql = "select * from weiuser where _id = ?";
		List<String> temp = new ArrayList<String>();
		temp.add(info._id+"");
		ResultSet set = dao.query(sql, temp);
		try {
			if (set.next()) {
				info._id = set.getInt("_id");
				info.username = set.getString("username");
				info.nickname = set.getString("nickname");
				info.headicon = set.getString("headicon");
				info.motto = set.getString("motto");
				info.sex = set.getString("sex");
				info.birth = set.getString("birth");
				info.isonline = set.getInt("isonline") == 0 ? false : true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return info;
	}
	
	public static UserInfo getUserName(int _id){
		UserInfo info = new UserInfo();
		info._id = _id;
		BaseDao dao = new BaseDao();
		String sql = "select * from weiuser where _id = ?";
		List<String> temp = new ArrayList<String>();
		temp.add(_id+"");
		ResultSet set = dao.query(sql, temp);
		try {
			if (set.next()) {
				info._id = set.getInt("_id");
				info.username = set.getString("username");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return info;
	}
	
	public static List<UserInfo> find(String account){
		BaseDao dao = new BaseDao();
		String sql = "select * from weiuser where username like ? or nickname like ?";
		List<String> temp = new ArrayList<String>();
		temp.add("%" + account + "%");
		temp.add("%" + account + "%");
		UserInfo info = null;
		List<UserInfo> infos = new ArrayList<UserInfo>();
		ResultSet set = dao.query(sql, temp);
		try {
			while (set.next()) {
				info = new UserInfo();
				info._id = set.getInt("_id");
				info.username = set.getString("username");
				info.nickname = set.getString("nickname");
				info.headicon = set.getString("headicon");
				info.motto = set.getString("motto");
				info.isonline = set.getInt("isonline") == 0 ? false : true;
				infos.add(info);
				info = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return infos;
	}
	
	public static void changeState(int _id , boolean isonline){
		BaseDao dao = new BaseDao();
		String sql = "update weiuser set isonline = ? where _id = ?";
		List<String> temp = new ArrayList<String>();
		temp.add((isonline? 1: 0) +"");
		temp.add(_id+"");
		try {
			dao.update(sql, temp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static List<UserInfo> getFriends(int _id){
		BaseDao dao = new BaseDao();
		String sql = "select * from weifriend where first_id = ?";
		List<String> temp = new ArrayList<String>();
		temp.add(_id+"");
		ResultSet set = dao.query(sql, temp);
		List<UserInfo> infos = new ArrayList<UserInfo>();
		UserInfo info = null;
		try {
			while (set.next()) {
				info = new UserInfo();
				info._id = set.getInt("second_id");
				info = search(info);
				info.exname = set.getString("second_remark");
				infos.add(info);
				info = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return infos;
	}
	
	public static boolean addFriend(int first_id, int second_id){
		BaseDao dao = new BaseDao();
		if (isFriend(first_id, second_id) != null) {
			return false;
		}
		String sql_fir = "insert into weifriend ( first_id , second_id,second_remark) values (?,?,?)";
		List<String> temp = new ArrayList<String>();
		temp.add(first_id+"");
		temp.add(second_id+"");
		temp.add(getUserName(second_id).username);
		boolean flag = dao.add(sql_fir, temp);
		if (flag) {
			String sql = "insert into weifriend ( first_id , second_id,second_remark) values (?,?,?)";
			temp = new ArrayList<String>();
			temp.add(second_id+"");
			temp.add(first_id+"");
			temp.add(getUserName(first_id).username);
			return dao.add(sql, temp);
		}
		return false;
	}
	
	public static UserInfo isFriend(int first_id, int second_id){
		BaseDao dao = new BaseDao();
		String sql = "select * from weifriend where first_id = ? and second_id = ?";
		List<String> temp = new ArrayList<String>();
		temp.add(first_id+"");
		temp.add(second_id+"");
		ResultSet set = dao.query(sql, temp);
		UserInfo info = null;
		try {
			if (set.next()) {
				info = new UserInfo();
				info._id = second_id;
				info = search(info);
				info.exname = set.getString("second_remark");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return info;
	}
	
	public static boolean changeNickname(int first_id, int second_id,String nickname){
		BaseDao dao = new BaseDao();
		String sql = "update weifriend set second_remark = ? where first_id = ? and second_id = ?";
		List<String> temp = new ArrayList<String>();
		temp.add(nickname);
		temp.add(first_id+"");
		temp.add(second_id+"");
		return dao.update(sql, temp);
	}
	
	public static boolean register(UserInfo info){
		BaseDao dao = new BaseDao();
		if (check(info.username)) {
			return false;
		}
		//            insert into 表名         ( 字段1，       字段2，...) values ('值1','值2'，....) where 条件;
		String sql = "insert into weiuser( username , password , sex , isonline) values ( ? , ? , '男' , '0')";
		List<String> temp = new ArrayList<String>();
		temp.add(info.username);
		temp.add(info.password);
		return dao.add(sql, temp);
	}
	
	public static boolean update(UserInfo info){
		BaseDao dao = new BaseDao();
		String sql = "update weiuser set nickname = ? ,motto = ? ,phone = ?,sex = ?  where _id = ?";
		List<String> temp = new ArrayList<String>();
		temp.add(info.nickname);
		temp.add(info.motto);
		temp.add(info.phone);
		temp.add("男".equals(info.sex) ? "男" : "女");
		temp.add(info._id+"");
		return dao.update(sql, temp);
	}
	
	public static boolean check(String username){
		BaseDao dao = new BaseDao();
		String sql = "select _id from weiuser where username = ?";
		List<String> temp = new ArrayList<String>();
		temp.add(username);
		ResultSet set = dao.query(sql, temp);
		try {
			if (set == null || !set.next()) {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	
	public static List<RecordMsgInfo> getRecord(int fir_id,int sec_id ){
		List<RecordMsgInfo> list = new ArrayList<RecordMsgInfo>();
		BaseDao dao = new BaseDao();
		String sql = "select * from weichating where flag = ? or flag = ? order by time asc";
		List<String> temp = new ArrayList<String>();
		temp.add(fir_id + "@" + sec_id);
		temp.add(sec_id + "@" + fir_id);
		ResultSet set = dao.query(sql, temp);
		RecordMsgInfo record = null;
		try {
			while (set.next()) {
				record = new RecordMsgInfo();
				record._id = set.getInt("_id");
				record.flag = set.getString("flag");
				record.msg = set.getString("msg");
				record.img = set.getString("img");
				record.voice = set.getString("voice");
				record.emoji = set.getInt("emoji");
				record.time = set.getString("time");
				list.add(record);
				record = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(list+"=====");
		return list;
	}
	
	public static boolean recordChating(RecordMsgInfo info){
		BaseDao dao = new BaseDao();
		String sql = "insert into weichating (flag , msg , img , voice , emoji , time ) values (?,?,?,?,?,?)";
		List<String> temp = new ArrayList<String>();
		temp.add(info.flag);
		temp.add(info.msg);
		temp.add(info.img);
		temp.add(info.voice);
		temp.add(info.emoji+"");
		temp.add(System.currentTimeMillis()+"");
		return dao.add(sql, temp);
	}
	
	public static String parseListRecordToJson(List<RecordMsgInfo> lists)throws Exception{
		Gson gson=new Gson();
		return gson.toJson(lists);
	}
	
	public static String parseListUserToJson(List<UserInfo> lists)throws Exception{
		Gson gson=new Gson();
		return gson.toJson(lists);
	}
	
	public static void main(String[] args) {
		UserInfo info = new UserInfo();
		info._id = 3;
		info.nickname = "我就是那个传说中的C";
		info.motto = "哥玩的是寂寞";
		info.phone = "00000000000";
		boolean flag = update(info);
		System.out.println(flag);
	}

}