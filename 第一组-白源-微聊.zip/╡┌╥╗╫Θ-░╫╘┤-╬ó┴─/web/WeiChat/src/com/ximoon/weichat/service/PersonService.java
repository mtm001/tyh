package com.ximoon.weichat.service;

import java.util.List;

import com.google.gson.Gson;
import com.ximoon.weichat.entity.BarUserInfo;

public class PersonService {
	
	//将List<Bean>->json
	public String parseListPersonToJSON(List<BarUserInfo> lists) throws Exception{
		//Gson是对Json的封装，谷歌提供的
		Gson gson = new Gson();
		return gson.toJson(lists);
	}
	
	
	//将List<Bean>->xml
	/**public void parseListPersonToXml(String path,List<BarUserInfo> lists) throws Exception{
		//1.输出流
		//将xml解析成ListBean
		//XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
		XmlSerializer serializer = XmlPullParserFactory.newInstance().newSerializer();
		FileOutputStream fos = new FileOutputStream(new File(path,"persons.xml"), false);//不追加
		serializer.setOutput(fos, "utf-8");
		serializer.startDocument("utf-8",true);
		//2.开始标签
		serializer.startTag(null, "persons");//命名空间,标签名
		//循环
		for (BarUserInfo BarUserInfo : lists) {
			serializer.startTag(null, "person");
			//_id
			serializer.startTag(null, "_id");
			serializer.text(BarUserInfo._id+"");
			serializer.endTag(null, "_id");
			//username
			serializer.startTag(null, "username");
			serializer.text(BarUserInfo.name);
			serializer.endTag(null, "username");
			//password
			serializer.startTag(null, "password");
			serializer.text(BarUserInfo.password);
			serializer.endTag(null, "password");
			//pic
			serializer.startTag(null, "pic");
			serializer.text(BarUserInfo.pic);
			serializer.endTag(null, "pic");
			
			serializer.endTag(null, "person");
		}
		
		serializer.endTag(null, "persons");
		serializer.endDocument();
		//关流
		fos.flush();//将内存中的内容写出去
		fos.close();
	}
	*/
}



