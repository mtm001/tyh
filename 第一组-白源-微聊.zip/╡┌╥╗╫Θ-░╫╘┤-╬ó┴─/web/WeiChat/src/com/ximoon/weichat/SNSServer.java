package com.ximoon.weichat;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class SNSServer {

	private ServerSocket serverSocket = null;
	public static List<ClientThread> clients = new ArrayList<ClientThread>();

	public void getConnection() {
		try {
			serverSocket = new ServerSocket(8282);
			System.out.println("服务器已经开启");
			while (true) {
				Socket socket = serverSocket.accept();
				ClientThread client = new ClientThread(socket);
				System.out.println("一个客户连上来了，地址是：" + client.ip + "端口号是："
						+ client.port);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		SNSServer server = new SNSServer();
		server.getConnection();
	}
}