package com.ximoon.weichat.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ximoon.weichat.entity.BarUserInfo;
import com.ximoon.weichat.entity.UserInfo;

public class UserDao extends BaseDao {
	//查
	public List<BarUserInfo> queryAllusers(){
		
		List<BarUserInfo> lists = null;
		
		String sql = "SELECT _id,theme,title,layer,content,time,user_id,name,pic from micro order by  _id desc";
		try {
			rs = super.query(sql, null);
			if(rs!=null){
				lists = new ArrayList<BarUserInfo>();
				while(rs.next()){
					int _id = rs.getInt(1);
					String theme = rs.getString(2);
					String title = rs.getString(3);
					int layer = rs.getInt(4);
					String content = rs.getString(5);
					String time = rs.getString(6);
					int user_id = rs.getInt(7);
					String name = rs.getString(8);
					String pic = rs.getString(9);
					BarUserInfo info = new BarUserInfo(_id, theme, title, layer,content,time,user_id,name,pic);
					lists.add(info);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lists;
	}
	public List<BarUserInfo> queryAllRecommandusers(){
		
		List<BarUserInfo> lists = null;
		
		String sql = "select * from (SELECT * from micro order by  layer desc) as tmp limit 5";
		try {
			rs = super.query(sql, null);
			if(rs!=null){
				lists = new ArrayList<BarUserInfo>();
				while(rs.next()){
					int _id = rs.getInt(1);
					String theme = rs.getString(2);
					String title = rs.getString(3);
					int layer = rs.getInt(4);
					String content = rs.getString(5);
					String time = rs.getString(6);
					int user_id = rs.getInt(7);
					String name = rs.getString(8);
					String pic = rs.getString(9);
					BarUserInfo info = new BarUserInfo(_id, theme, title, layer,content,time,user_id,name,pic);
					lists.add(info);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lists;
	}
	
	public List<BarUserInfo> queryAllReplies(){
		
		List<BarUserInfo> lists = null;
		
		String sql = "SELECT _id,theme,title,layer,content,time,user_id,name,pic from micro_reply order by  _id desc";
		try {
			rs = super.query(sql, null);
			if(rs!=null){
				lists = new ArrayList<BarUserInfo>();
				while(rs.next()){
					int _id = rs.getInt(1);
					String theme = rs.getString(2);
					String title = rs.getString(3);
					int layer = rs.getInt(4);
					String content = rs.getString(5);
					String time = rs.getString(6);
					int user_id = rs.getInt(7);
					String name = rs.getString(8);
					String pic = rs.getString(9);
					BarUserInfo info = new BarUserInfo(_id, theme, title, layer,content,time,user_id,name,pic);
					lists.add(info);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lists;
	}
	public boolean insertReply(BarUserInfo BarUserInfo){
		boolean flag=false;
		List<String> temp=new ArrayList<String>();
		temp.add(BarUserInfo.theme);
		temp.add(BarUserInfo.title);
		temp.add(BarUserInfo.layer+"");
		temp.add(BarUserInfo.content);
		temp.add(BarUserInfo.time);
		temp.add(BarUserInfo.user_id+"");
		temp.add(BarUserInfo.name);
		temp.add("");
		String sql = "insert into micro_reply (theme,title,layer,content,time,user_id,name,pic) values(?,?,?,?,?,?,?,?)";
		
		flag= super.update(sql, temp);
			
		return flag;
	}
	public boolean insertTitle(BarUserInfo BarUserInfo){
		boolean flag=false;
		List<String> temp=new ArrayList<String>();
		temp.add(BarUserInfo.theme);
		temp.add(BarUserInfo.title);
		temp.add(BarUserInfo.layer+"");
		temp.add(BarUserInfo.content);
		temp.add(BarUserInfo.time);
		temp.add(BarUserInfo.user_id+"");
		temp.add(BarUserInfo.name);
		temp.add(BarUserInfo.pic);
		String sql = "insert into micro (theme,title,layer,content,time,user_id,name,pic) values(?,?,?,?,?,?,?,?)";
		
		flag= super.update(sql, temp);
		
		return flag;
	}
	public boolean insertLayer(String title,int layer){
		boolean flag=false;
		List<String> temp=new ArrayList<String>();
		temp.add(layer+"");
		temp.add(title);
		
		String sql = "update micro set layer=?  where title=?";
		flag= super.update(sql, temp);
		
		return flag;
	}
	public boolean insertPic(String title,String pic){
		boolean flag=false;
		List<String> temp=new ArrayList<String>();
		temp.add(pic);
		temp.add(title);
		
		String sql = "update micro set pic=?  where title=?";
		flag= super.update(sql, temp);
		
		return flag;
	}
	
	
}
