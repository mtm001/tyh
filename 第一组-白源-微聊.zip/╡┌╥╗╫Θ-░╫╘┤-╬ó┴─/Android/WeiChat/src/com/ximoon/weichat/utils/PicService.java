package com.ximoon.weichat.utils;

import com.ximoon.weichat.R;

public class PicService {
	public static int[] getPic(){
		int[] imgsId={
				R.drawable.f_static_000,R.drawable.f_static_001,R.drawable.f_static_002,
				R.drawable.f_static_003,R.drawable.f_static_004,R.drawable.f_static_005,
				R.drawable.f_static_006,R.drawable.f_static_007,R.drawable.f_static_008,
				R.drawable.f_static_009,R.drawable.f_static_010,R.drawable.f_static_011,
				R.drawable.f_static_012,R.drawable.f_static_013,R.drawable.f_static_014,
				R.drawable.f_static_015,R.drawable.f_static_016,R.drawable.f_static_017,
				R.drawable.f_static_018,R.drawable.f_static_019,R.drawable.f_static_020,
				R.drawable.f_static_021,R.drawable.f_static_022,R.drawable.f_static_023,
				R.drawable.f_static_024,R.drawable.f_static_025,R.drawable.f_static_026,
				R.drawable.f_static_027,R.drawable.f_static_028,R.drawable.f_static_029,
				R.drawable.f_static_030,R.drawable.f_static_031,R.drawable.f_static_032,
				R.drawable.f_static_033,R.drawable.f_static_034,R.drawable.f_static_035,
				R.drawable.f_static_036,R.drawable.f_static_037,R.drawable.f_static_038,
				R.drawable.f_static_039,R.drawable.f_static_040,R.drawable.f_static_041,
				R.drawable.f_static_042,R.drawable.f_static_043,R.drawable.f_static_044,
				R.drawable.f_static_045,R.drawable.f_static_046,R.drawable.f_static_047,
				R.drawable.f_static_048,R.drawable.f_static_049,R.drawable.f_static_050,
				R.drawable.f_static_051
		};
		return imgsId;
	}
}