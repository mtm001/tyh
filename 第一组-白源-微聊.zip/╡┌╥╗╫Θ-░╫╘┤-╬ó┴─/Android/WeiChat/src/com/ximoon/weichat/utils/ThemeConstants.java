package com.ximoon.weichat.utils;

public class ThemeConstants {
	public static final String JOKE_THEME = "笑话";
	public static final String SUPERSTAR_THEME="明星";
	public static final String SCIENCE_THEME="科教";
	public static final String NEWS_THEME="新闻";
	public static final String HANDSOME_THEME="帅哥";
	public static final String POLICY_THEME="政治";
	public static final String ECONOMY_THEME = "经济";
	public static final String BEAUTY_THEME = "美女";
	public static final String PE_THEME = "体育";
	public static final String KATY_THEME = "katy perry";
	public static final String SHAYNE_THEME ="shayne ward";
}
