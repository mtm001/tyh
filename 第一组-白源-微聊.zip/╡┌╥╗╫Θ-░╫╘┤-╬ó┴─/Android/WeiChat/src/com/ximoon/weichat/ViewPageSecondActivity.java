package com.ximoon.weichat;


import android.app.Activity;
import android.os.Bundle;

public class ViewPageSecondActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.second_viewpage_main_);
		
	}


}
