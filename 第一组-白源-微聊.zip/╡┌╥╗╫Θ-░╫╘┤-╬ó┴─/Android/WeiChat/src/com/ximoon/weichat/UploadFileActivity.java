package com.ximoon.weichat;


import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;

public class UploadFileActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_mysetting_message);
		
	}
	public void flytobrave(View view){
//		Intent intent=new Intent(UploadFileActivity.this,TruthOrBraveActivity.class);
//		startActivity(intent);
	}
	
}
