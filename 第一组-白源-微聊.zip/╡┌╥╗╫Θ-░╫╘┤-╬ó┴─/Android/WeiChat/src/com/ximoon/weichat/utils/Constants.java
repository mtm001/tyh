package com.ximoon.weichat.utils;

public class Constants {
	//地图的key
	public static final String MAP_KEY = "OHZSG3KW8LsgGPDsGmdIUjNg";
	//销毁的广播
	public static final String ACTIVITY_DESTORY_ACTION = "com_muzili_activity_destory_action";
	//讯飞的appid
	public static final String XUNFEI_APPID = "5212ef0a";
	//打电话的action
	public static final String ACTIVITY_CALL_ACTION="weichat_call_action";
	//发短信的action
	public static final String ACTIVITY_SENDMESSAGE_ACTION="weichat_sendmessage_action";
	//真心话大冒险的action
	public static final String ACTIVITY_TRUTHORBRAVE_ACTION="weichat_truthorbrave_action";
	//
	public static final String ACTIVITY_CAMERA_ACTION="weichat_camera_action";
}
